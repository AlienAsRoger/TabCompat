package com.example.themes;

import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.android.tabcompat.CompatTab;
import com.example.android.tabcompat.CompatTabListener;
import com.example.android.tabcompat.TabCompatActivity;
import com.example.android.tabcompat.TabHelper;

public class ThemesActivity extends TabCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        TabHelper tabHelper = getTabHelper();
        
        // Add a couple tabs
        CompatTab artistTab = tabHelper.newTab("artists");
        artistTab.setText(R.string.artists);
        artistTab.setIcon(R.drawable.ic_tab_artists);
        artistTab.setTabListener(new TabListener<ArtistFragment>(
                this, ArtistFragment.class));
        tabHelper.addTab(artistTab);
        
        CompatTab albumTab = tabHelper.newTab("albums");
        albumTab.setText(R.string.albums);
        albumTab.setTabListener(new TabListener<AlbumFragment>(
                this, AlbumFragment.class));
        tabHelper.addTab(albumTab);
    }
    
    /** Implementation of CompatTabListener to handle tab change events */
    public static class TabListener<T extends Fragment> implements CompatTabListener {
      private final TabCompatActivity mActivity;
      private final Class<T> mClass;
      private final int mContainerId;

      /** Constructor used each time a new tab is created.
        * @param activity  The host Activity, used to instantiate the fragment
        * @param clz  The fragment's Class, used to instantiate the fragment
        */
      public TabListener(TabCompatActivity activity, Class<T> clz) {
          mActivity = activity;
          mClass = clz;
          mContainerId = Build.VERSION.SDK_INT >= 11 ? android.R.id.content : R.id.realtabcontent;
      }

      /* The following are each of the ActionBar.TabListener callbacks */
      @Override
      public void onTabSelected(CompatTab tab, FragmentTransaction ft) {
          // Check if the fragment is already initialized
          Fragment fragment = tab.getFragment();
          if (fragment == null) {
              // If not, instantiate and add it to the activity
              fragment = Fragment.instantiate(mActivity, mClass.getName());
              tab.setFragment(fragment);
              ft.add(mContainerId, fragment, tab.getTag());
          } else {
              // If it exists, simply attach it in order to show it
              ft.attach(fragment);
          }
      }

      @Override
      public void onTabUnselected(CompatTab tab, FragmentTransaction ft) {
          Fragment fragment = tab.getFragment();
          if (fragment != null) {
              // Detach the fragment, because another one is being attached
              ft.detach(fragment);
          }
      }

      @Override
      public void onTabReselected(CompatTab tab, FragmentTransaction ft) {
          // User selected the already selected tab. Meh.
      }
  }

    
    
    
    /** Fancy fragment classes */
    
    public static class ArtistFragment extends Fragment {
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
            TextView text = new TextView(getActivity());
            int padding = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                    8, getActivity().getResources().getDisplayMetrics());
            text.setPadding(padding, padding, padding, padding);
            text.setText("Hell yeah");
            return text;
        }
    }
    
    
    public static class AlbumFragment extends Fragment {
        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
            TextView text = new TextView(getActivity());
            int padding = (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                    8, getActivity().getResources().getDisplayMetrics());
            text.setPadding(padding, padding, padding, padding);
            text.setText("That's whasup");
            return text;
        }
    }
}