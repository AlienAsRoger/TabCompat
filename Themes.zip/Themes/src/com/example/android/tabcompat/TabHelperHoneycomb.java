// Copyright 2012 Google Inc. All Rights Reserved.

package com.example.android.tabcompat;

import android.app.ActionBar;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;

/**
 * Helper class to build tabs on Honeycomb.
 * Call getTabHelper() to get the generic instance for compatibility
 * with older versions.
 */
public class TabHelperHoneycomb extends TabHelper {
    ActionBar mActionBar;

  protected TabHelperHoneycomb(FragmentActivity activity) {
      super(activity);
  }

  @Override
  public void addTab(CompatTab tab) {
      String tag = tab.getTag();
  
      // Check to see if we already have a fragment for this tab, probably
      // from a previously saved state.  If so, deactivate it, because our
      // initial state is that a tab isn't shown.
      Fragment fragment = mActivity.getSupportFragmentManager().findFragmentByTag(tag);
      tab.setFragment(fragment);
      if (fragment != null && !fragment.isDetached()) {
          FragmentTransaction ft = mActivity.getSupportFragmentManager().beginTransaction();
          ft.detach(fragment);
          ft.commit();
      }
      if (tab.getCallback() == null) {
          throw new IllegalStateException("CompatTab must have a CompatTabListener");
      }
      mActionBar.addTab((ActionBar.Tab)tab.getTab());
  }

  @Override
  public void setUp() { 
      if (mActionBar == null) {
          mActionBar = mActivity.getActionBar();

          mActionBar = mActivity.getActionBar();
          mActionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
      }
  }

  @Override
  public void onSaveInstanceState(Bundle outState) { 
    int position = mActionBar.getSelectedTab().getPosition();
    outState.putInt("tabposition", position);
  }

  @Override
  public void onRestoreInstanceState(Bundle savedInstanceState) { 
    int position = savedInstanceState.getInt("tabposition");
    mActionBar.setSelectedNavigationItem(position);
  }
  
}
