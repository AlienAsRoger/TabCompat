// Copyright 2012 Google Inc. All Rights Reserved.

package com.example.android.tabcompat;

import android.support.v4.app.FragmentTransaction;



public interface CompatTabListener {
  /**
   * Called when a tab enters the selected state.
   *
   * @param tab The tab that was selected
   * @param ft A {@link FragmentTransaction} for queuing fragment operations to execute
   *        during a tab switch. The previous tab's unselect and this tab's select will be
   *        executed in a single transaction. This FragmentTransaction does not support
   *        being added to the back stack.
   */
  public void onTabSelected(CompatTab tab, FragmentTransaction ft);

  /**
   * Called when a tab exits the selected state.
   *
   * @param tab The tab that was unselected
   * @param ft A {@link FragmentTransaction} for queuing fragment operations to execute
   *        during a tab switch. This tab's unselect and the newly selected tab's select
   *        will be executed in a single transaction. This FragmentTransaction does not
   *        support being added to the back stack.
   */
  public void onTabUnselected(CompatTab tab, FragmentTransaction ft);

  /**
   * Called when a tab that is already selected is chosen again by the user.
   * Some applications may use this action to return to the top level of a category.
   *
   * @param tab The tab that was reselected.
   * @param ft A {@link FragmentTransaction} for queuing fragment operations to execute
   *        once this method returns. This FragmentTransaction does not support
   *        being added to the back stack.
   */
  public void onTabReselected(CompatTab tab, FragmentTransaction ft);

}
