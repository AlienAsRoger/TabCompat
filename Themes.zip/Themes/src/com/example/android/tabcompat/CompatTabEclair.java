// Copyright 2012 Google Inc. All Rights Reserved.

package com.example.android.tabcompat;

import android.graphics.drawable.Drawable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.widget.TabHost;

/** 
 * Obfuscates the TabHost.TabSpec APIs 
 * */
public class CompatTabEclair extends CompatTab {
    private TabHost.TabSpec mTabSpec;
    private CompatTabListener mCallback;
    private CharSequence mText;
    private Drawable mIcon;
    private Fragment mFragment;

    protected CompatTabEclair(FragmentActivity activity, String tag) {
        super(activity, tag);
    }
  
    @Override
    public CompatTab setText(int resId) {
        mText = mActivity.getResources().getText(resId);
        return this;
    }
  
    @Override
    public CompatTab setIcon(int resId) {
        mIcon = mActivity.getResources().getDrawable(resId);
        return this;
    }

    @Override
    public CompatTab setTabListener(CompatTabListener callback) {
        mCallback = callback;
        return this;
    }
    
    @Override
    public void setFragment(Fragment fragment) {
        mFragment = fragment;
    }
    
    @Override
    public Fragment getFragment() {
        return mFragment;
    }

    @Override
    public CharSequence getText() {
        return mText;
    }

    @Override
    public Drawable getIcon() {
        return mIcon;
    }

    @Override
    public Object getTab() {
        return mTabSpec;
    }
    
    @Override
    CompatTabListener getCallback() {
        return mCallback;
    }

}
