// Copyright 2012 Google Inc. All Rights Reserved.

package com.example.android.tabcompat;

import android.graphics.drawable.Drawable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;

/**
 * Represents a single tab.
 * The TabHelper initializes one of the subclasses of this based
 * on the current platform version, upon call to TabHelper.newTab()
 */
public abstract class CompatTab {
    final FragmentActivity mActivity;
    final String mTag;
    
    protected CompatTab(FragmentActivity activity, String tag) {
        mActivity = activity;
        mTag = tag;
    }
    
    public abstract CompatTab setText(int resId);
    
    public abstract CompatTab setIcon(int resId);
    
    public abstract CompatTab setTabListener(CompatTabListener callback);

    public abstract void setFragment(Fragment fragment);
    
    public abstract Fragment getFragment();
    
    public abstract CharSequence getText();

    public abstract Drawable getIcon();
    
    public abstract Object getTab();
    
    abstract CompatTabListener getCallback();
    
    public String getTag() {
        return mTag;
    }
    
}
